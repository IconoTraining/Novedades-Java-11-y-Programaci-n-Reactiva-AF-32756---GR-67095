package es.indra.interfaz;

public interface ItfzSaludo {
	
	String saludar();

}
