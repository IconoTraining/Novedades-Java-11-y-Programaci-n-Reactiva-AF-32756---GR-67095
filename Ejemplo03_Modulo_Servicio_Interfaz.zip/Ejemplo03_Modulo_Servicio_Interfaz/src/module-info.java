/**
 * 
 */
/**
 * 
 */
module Ejemplo03_Modulo_Servicio_Interfaz {
	
	exports es.indra.interfaz;
}