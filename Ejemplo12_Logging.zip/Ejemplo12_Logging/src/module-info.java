/**
 * 
 */
/**
 * 
 */
module Ejemplo12_Logging {
	
	requires java.logging;
}