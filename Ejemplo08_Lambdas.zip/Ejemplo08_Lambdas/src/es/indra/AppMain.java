package es.indra;

import es.indra.business.ItfzEmpleados;

public class AppMain {

	public static void main(String[] args) {
		
		// Sintaxis lambda:   (parametros) -> {cuerpo del metodo}
		// Los parentesis son obligatorios: ponemos tipo al parametro o son mas de 1 parametro
		// Las llaves son obligatorias: tenemos mas de 1 linea de codigo o le ponemos return
		
		ItfzEmpleados lambda1 = (nombre, edad) -> "Nombre: " + nombre + ", edad: " + edad;
		System.out.println(lambda1.detalle("Juan", 36));
		
		ItfzEmpleados lambda2 = (nombre, edad) -> {
			return "Nombre: " + nombre + ", edad: " + edad;
		};
		System.out.println(lambda2.detalle("Juan", 36));
		
		ItfzEmpleados lambda3 = (nombre, edad) -> {
			nombre = nombre.toUpperCase();
			edad += 1;
			return "Nombre: " + nombre + ", edad: " + edad;
		};
		System.out.println(lambda3.detalle("Juan", 36));
		
		// Los parametros no tienen porque llamarse igual que en la declaracion de la interface
		ItfzEmpleados lambda4 = (nom, e) -> "Nombre: " + nom + ", edad: " + e;
		System.out.println(lambda4.detalle("Juan", 36));
		
		// Podemos poner el tipo de dato a los parametros
		ItfzEmpleados lambda5 = (String nom, int e) -> "Nombre: " + nom + ", edad: " + e;
		System.out.println(lambda5.detalle("Juan", 36));
		
		// Podemos usar inferencia de tipos en los parametros
		ItfzEmpleados lambda6 = (var nom, var e) -> "Nombre: " + nom + ", edad: " + e;
		System.out.println(lambda6.detalle("Juan", 36));

	}

}
