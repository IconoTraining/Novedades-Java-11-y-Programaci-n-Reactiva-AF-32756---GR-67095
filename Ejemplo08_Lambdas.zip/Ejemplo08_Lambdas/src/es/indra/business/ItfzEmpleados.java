package es.indra.business;

@FunctionalInterface
public interface ItfzEmpleados {
	
	// Debe tener solo un metodo abstracto
	public abstract String detalle(String nombre, int edad);

}
