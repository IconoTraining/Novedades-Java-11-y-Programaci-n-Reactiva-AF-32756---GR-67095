/**
 * 
 */
/**
 * 
 */
module Ejemplo08_Lambdas {
}