/**
 * 
 */
/**
 * 
 */
module Ejercicio2_Modulo_Proveedor_Calculadora {
	
	requires Ejercicio_Servicio_Calculadora;
	provides es.indra.interfaz.ItfzCalculadora with es.indra.business.Calculadora;
}