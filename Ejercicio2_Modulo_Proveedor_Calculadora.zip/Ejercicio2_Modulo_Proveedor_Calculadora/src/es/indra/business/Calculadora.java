package es.indra.business;

import es.indra.interfaz.ItfzCalculadora;

public class Calculadora implements ItfzCalculadora{

	@Override
	public double sumar(double... numeros) {
		double resultado = 0;
		for (double num : numeros) {
			resultado += num;
		}
		return resultado;
	}

	@Override
	public double restar(double n1, double n2) {
		return n1 - n2;
	}

	@Override
	public double multiplicar(double n1, double n2) {
		return n1 * n2;
	}

	@Override
	public double dividir(double n1, double n2) {
		return n1 / n2;
	}

}
