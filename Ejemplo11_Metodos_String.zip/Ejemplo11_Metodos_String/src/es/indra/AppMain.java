package es.indra;

public class AppMain {

	public static void main(String[] args) {
		
		// isBlank()
		System.out.println("Hola".isBlank());
		System.out.println(" ".isBlank());
		System.out.println("".isBlank());
		System.out.println("\t".isBlank());
		System.out.println("\n".isBlank());
		
		
		// repeat()
		System.out.println("-".repeat(10));
		System.out.println("*".repeat(10));
		System.out.println("ja".repeat(10));
		
		
		// strip()
		String nombre = "    Juan    ";
		System.out.println("Hola," + nombre + ".");
		
		// Quitar los espacios derecha e izquierda
		System.out.println("Hola," + nombre.strip() + ".");
		
		// Quitar los espacios derecha
		System.out.println("Hola," + nombre.stripTrailing() + ".");
		
		// Quitar los espacios izquierda
		System.out.println("Hola," + nombre.stripLeading() + ".");

	}

}
