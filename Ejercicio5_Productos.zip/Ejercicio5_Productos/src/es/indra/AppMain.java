package es.indra;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;

import es.indra.models.Producto;

public class AppMain {

	public static void main(String[] args) throws IOException {

		Path ficheroLectura = Paths.get("/Users/anaisabelvegascaceres/Desktop/productos.txt");
		Path ficheroEscritura = Paths.get("/Users/anaisabelvegascaceres/Desktop/productos2.txt");

		// Borrar el fichero si existe
		Files.deleteIfExists(ficheroEscritura);

		// Crear el fichero
		Files.createFile(ficheroEscritura);
		
		try {
			List<String> lineas = Files.readAllLines(ficheroLectura);
			
			for (String linea : lineas) {
				// Partir por -
				String[] datos = linea.split("-");
				
				// Eliminar los espacios en blanco
				for(var i = 0; i < datos.length; i++) {
					datos[i] = datos[i].strip();		
				}
				
				// Crear la instancia de producto
				Producto producto = new Producto();
				producto.setId(Integer.parseInt(datos[0]));
				producto.setDescripcion(datos[1]);
				producto.setPrecio(Double.parseDouble(datos[2]));
				
				Files.writeString(ficheroEscritura, producto.toString(), StandardOpenOption.APPEND);
				Files.writeString(ficheroEscritura,"\n" , StandardOpenOption.APPEND);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
