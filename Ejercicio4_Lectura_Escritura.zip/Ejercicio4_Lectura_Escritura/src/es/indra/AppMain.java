package es.indra;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;

public class AppMain {

	public static void main(String[] args) {
		
		Path fileInput = Paths.get("entrada.txt");
		Path fileOutput = Paths.get("salida.txt");
		
		try {
			
			List<String> lineas = Files.readAllLines(fileInput);
			for (String linea : lineas) {
				Files.writeString(fileOutput, linea.toUpperCase() + "\n", 
						StandardOpenOption.APPEND);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
