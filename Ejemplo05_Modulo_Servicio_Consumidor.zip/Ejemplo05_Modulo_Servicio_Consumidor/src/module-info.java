/**
 * 
 */
/**
 * 
 */
module Ejemplo05_Modulo_Servicio_Consumidor {
	
	// Necesito el modulo donde esta declarada la interface
	requires Ejemplo03_Modulo_Servicio_Interfaz;
	
	// Necesito indicar cual es la interface
	uses es.indra.interfaz.ItfzSaludo;
}