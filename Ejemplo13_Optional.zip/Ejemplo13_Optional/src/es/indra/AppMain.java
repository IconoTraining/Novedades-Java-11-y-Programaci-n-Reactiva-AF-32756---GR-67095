package es.indra;

import java.util.Optional;
import java.util.stream.Stream;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;

public class AppMain {
	
	public static void main(String[] args) {
		
		ProductosDAO dao = new ProductosDAO();
		
		// Buscar un producto que existe
		System.out.println("Encontrado: " + dao.buscarProducto(2).get());
		
		// Buscar un producto que NO existe
		// java.util.NoSuchElementException: No value present
		//System.out.println("Encontrado: " + dao.buscarProducto(22222).get());
		
		// 1ª Forma de evitar la excepcion
		System.out.println("Encontrado: " + dao.buscarProducto(22222).orElse(new Producto()));
		
		// 2ª Forma de evitar la excepcion
		Optional<Producto> opProducto = dao.buscarProducto(22222);
		if (opProducto.isPresent()) {
			System.out.println(opProducto.get());
		} else {
			System.out.println("Producto no encontrado");
		}
		
		// 3ª Forma crear nuestra propia excepcion
		// orElseThrow nuevo en Java 11
		//Producto producto = opProducto.orElseThrow(() -> new RuntimeException("Producto no encontrado"));
		
		// stream nuevo en Java 11
		opProducto = dao.buscarProducto(2);
		Stream<Producto> stream = opProducto.stream();
		stream
			.map(item -> item.getDescripcion().toUpperCase())
			.forEach(System.out::println);
	}

}
