package es.indra.persistence;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import es.indra.models.Producto;

public class ProductosDAO {
	
	private List<Producto> lista = Arrays.asList(
			new Producto(1, "Pantalla", 129.95),
			new Producto(2, "Teclado", 50.85),
			new Producto(3, "Raton", 19.50));

	
	public Optional<Producto> buscarProducto(int id){
		
		for(Producto p : lista) {
			if (id == p.getId()) {
				return Optional.of(p);
			}
		}
		
		// Si no lo encuentra devuelve un Optional vacio
		return Optional.empty();
		
	}
}
