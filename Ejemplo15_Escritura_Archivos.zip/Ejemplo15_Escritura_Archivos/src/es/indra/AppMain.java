package es.indra;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Scanner;

public class AppMain {

	public static void main(String[] args) {
		
		Path path = Paths.get("texto.txt");
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Introduce texto (FIN para terminar): ");
		String texto = sc.nextLine();
		
		while (! "FIN".equals(texto)) {
			try {
				Files.writeString(path, texto, StandardOpenOption.APPEND);
				Files.writeString(path, "\n", StandardOpenOption.APPEND);
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			System.out.println("Introduce texto (FIN para terminar): ");
			texto = sc.nextLine();
		}
	}
}
