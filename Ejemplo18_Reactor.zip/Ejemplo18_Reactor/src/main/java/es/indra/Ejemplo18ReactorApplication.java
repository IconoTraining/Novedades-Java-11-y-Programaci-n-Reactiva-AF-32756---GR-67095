package es.indra;

import java.util.Arrays;
import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.indra.models.Producto;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@SpringBootApplication
public class Ejemplo18ReactorApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo18ReactorApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		crearMono();
	}
	
	public void crearMono() {
		Mono<String> mono = Mono.just("hola");
		mono.subscribe(System.out::println);
	}
	
	public void combinarFlujos() {
		// Crear un flujo con numeros del 1 al 10
		// Crear otro flujo con numeros del 21 al 30
		Flux<Integer> numeros1 = Flux.range(1, 10);
		Flux<Integer> numeros2 = Flux.range(21, 10);
		
		// Combinar ambos flujos devolviendo la suma: 1+21, 2+22, 3+23, .......
		numeros1.zipWith(numeros2, (n1,n2) -> new Integer(n1+n2))
			.subscribe(item -> System.out.println(item));
	}
	
	public void rango() {
		Flux<Integer> numeros = Flux.range(1, 10);  // 10 elementos comenzando en 1
		numeros.subscribe(System.out::println);
	}
	
	public void complete() {
		Flux<String> datos = Flux.just("uno", "dos", "tres", "cuatro")
				.doOnNext(dato -> System.out.println(dato))
				.doOnComplete(new Runnable() {
					
					// Este metodo run se ejecuta al terminar de procesar todo el flujo
					@Override
					public void run() {
						System.out.println("------ FIN -----");
					}
				});
		datos.subscribe();
	}
	
	public void crear_Flujo_Lista() {
		// Crear el flujo a partir de un iterable
		// OJO!!! los arrays no son iterables
		List<Producto> lista = Arrays.asList(
				new Producto(1, "Pantalla", 129.95),
				new Producto(2, "Teclado", 50.85),
				new Producto(3, "Raton", 19.50));
		
		Flux.fromIterable(lista)
			.filter(p -> p.getPrecio() > 50)
			.map(prod -> {
				prod.setDescripcion(prod.getDescripcion().toUpperCase());
				return prod;
			})
			.doOnNext(System.out::println)
			.subscribe();
		
		
	}
	
	public void crear_Flujo() {
		// Tenemos 2 tipos de flujos:
		//       - Flux (varios elementos en el flujo)
		//       - Mono (un solo elemento en el flujo)
		
		// Crear un flujo de varios datos y mostrar cada uno en consola
//		Flux<String> datos = Flux.just("uno", "dos", "tres", "cuatro")
//				.doOnNext(dato -> System.out.println(dato));
		
		// Manejar excepciones
		Flux<String> datos = Flux.just("uno", "dos" ,"" ,"tres", "cuatro")
				.doOnNext(dato -> {
					if (dato.isEmpty()) {
						throw new RuntimeException("Dato vacio");
					}
					System.out.println(dato);
				});
		
		// Hasta que no se subscribe al flujo, no hace nada
		datos.subscribe();
		
	}

}
