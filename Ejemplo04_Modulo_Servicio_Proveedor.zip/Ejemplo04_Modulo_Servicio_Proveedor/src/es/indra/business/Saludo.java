package es.indra.business;

import es.indra.interfaz.ItfzSaludo;

public class Saludo implements ItfzSaludo{

	@Override
	public String saludar() {
		return "Bienvenidos a mi prueba de servicios con modulos";
	}
	
	

}
