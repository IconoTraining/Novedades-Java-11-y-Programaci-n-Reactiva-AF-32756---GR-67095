/**
 * 
 */
/**
 * 
 */
module Ejemplo04_Modulo_Servicio_Proveedor {
	
	// Necesito el modulo donde tengo la interfaz
	requires Ejemplo03_Modulo_Servicio_Interfaz;
	
	// Proporcionamos una clase que implementa la interface
	provides es.indra.interfaz.ItfzSaludo with es.indra.business.Saludo;
}