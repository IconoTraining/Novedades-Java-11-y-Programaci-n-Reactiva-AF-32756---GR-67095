package es.indra;

import java.util.ServiceLoader;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import es.indra.interfaz.ItfzCalculadora;

public class AppMain {

	public static void main(String[] args) {
		
		ServiceLoader<ItfzCalculadora> loader = ServiceLoader.load(ItfzCalculadora.class);
		Iterable<ItfzCalculadora> iterable = () -> loader.iterator();
		Stream<ItfzCalculadora> stream = StreamSupport.stream(iterable.spliterator(), false);
		ItfzCalculadora calculadora = stream.findFirst().get();
		
		System.out.println("7 + 5 + 3 + 2 = " + calculadora.sumar(7,5,3,2));
		System.out.println("7 - 3 = " + calculadora.restar(7, 3));
		System.out.println("7 * 3 = " + calculadora.multiplicar(7, 3));
		System.out.println("7 / 3 = " + calculadora.dividir(7, 3));

	}

}
