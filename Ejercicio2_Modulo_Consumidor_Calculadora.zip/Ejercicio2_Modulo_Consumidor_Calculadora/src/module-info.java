/**
 * 
 */
/**
 * 
 */
module Ejercicio2_Modulo_Consumidor_Calculadora {
	
	requires Ejercicio_Servicio_Calculadora;
	uses es.indra.interfaz.ItfzCalculadora;
}