package es.indra;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class AppMain {

	public static void main(String[] args) {
		
		String fichero = "datos.txt";
		Path path = Paths.get(fichero);
		
		
		try {
			// 1ª forma
			String contenido = Files.readString(path);
			System.out.println(contenido);
			
			// 2ª forma
			List<String> lineas = Files.readAllLines(path);
			lineas.forEach(System.out::println);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
