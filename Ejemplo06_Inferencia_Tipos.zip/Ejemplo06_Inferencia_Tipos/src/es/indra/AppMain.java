package es.indra;

import java.util.ArrayList;
import java.util.Arrays;

public class AppMain {
	
	// en las variables globales no funciona la inferencia de tipos
	//var prueba = 67;

	public static void main(String[] args) {
		
		var prueba = 67;
		
		// Una vez asignado un valor, toma ese tipo de datos
		// y no soporta otro valor de otro tipo
		//prueba = "hola";
		
		// No se puede aplicar a variables sin inicializar o nulas
		//var prueba2;
		//var prueba3 = null;
		
		// No es viable si se declaran mas de una variable por linea
		//var prueba4, prueba5 = 6;
		//var prueba4 = 6, prueba5 = 6;
		
		// Arrays
		//var numeros = {1,2,3,4,5};
		var numeros = new int[] {1,2,3,4,5};
		
		// Colecciones (list, set, map)
		var lista = new ArrayList<>();   // lista de objetos
		var lista2 = new ArrayList<Integer>(); // lista de numeros enteros
		var lista3 = new ArrayList<>(Arrays.asList(1,2,3,4)); // lista de numeros enteros
		var lista4 = new ArrayList<Integer>(Arrays.asList(1,2,3,4)); // lista de numeros enteros
		
		// Variables de bucle
		for(var i = 0; i < numeros.length; i++) {
			System.out.println(numeros[i]);
		}
		
		for (var num : lista4) {
			System.out.println(num);
		}	
		
	}

}
