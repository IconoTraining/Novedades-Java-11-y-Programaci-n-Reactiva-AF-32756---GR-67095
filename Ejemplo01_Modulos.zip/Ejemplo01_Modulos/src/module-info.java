/**
 * 
 */
/**
 * 
 */
module Ejemplo01_Modulos {
	
	// exports paquete
	exports es.indra.models;
	
}