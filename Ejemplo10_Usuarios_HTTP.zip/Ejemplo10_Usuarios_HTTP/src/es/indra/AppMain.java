package es.indra;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.json.JSONArray;
import org.json.JSONObject;

public class AppMain {

	public static void main(String[] args) throws URISyntaxException, IOException, InterruptedException {
		
		String url = "https://jsonplaceholder.typicode.com/users";
		
		// Preparar la peticion
		URI uri = new URI(url);
		HttpRequest request = HttpRequest.newBuilder(uri).GET().build();
		
		// Contenedor cliente
		HttpClient client = HttpClient.newHttpClient();
		
		// Enviar la peticion y recibimos la respuesta
		HttpResponse<String> respuesta = client.send(request, HttpResponse.BodyHandlers.ofString());
		//System.out.println(respuesta.body());
		
		// Convertir ese String en un array de JSON
		JSONArray jsonArray = new JSONArray(respuesta.body());
		
		// Recorrer el array y por cada objeto generar un objeto JSON
		for (Object object : jsonArray) {
			JSONObject jsonObject = new JSONObject(object.toString());
			
			// Mostrar los datos del usuario
			System.out.println("ID: " + jsonObject.getInt("id"));
			System.out.println("Nombre: " + jsonObject.getString("name"));
			System.out.println("Usuario: " + jsonObject.getString("username"));
			System.out.println("Email: " + jsonObject.getString("email"));
			
			
			JSONObject jsonDireccion = jsonObject.getJSONObject("address");
			System.out.println("Calle: " + jsonDireccion.getString("street"));
			System.out.println("Numero: " + jsonDireccion.getString("suite"));
			System.out.println("Ciudad: " + jsonDireccion.getString("city"));
			System.out.println("Codigo postal: " + jsonDireccion.getString("zipcode"));
			
			
			JSONObject jsonGeo = jsonDireccion.getJSONObject("geo");
			System.out.println("Latitud: " + jsonGeo.getString("lat"));
			System.out.println("Longitud: " + jsonGeo.getString("lng"));
			
			System.out.println("----------------------");
			
		}

	}

}


// Con el API pokemons  https://pokeapi.co/api/v2/pokemon/
//   1.- mostrar los nombres de los 20 pokemons
//	 2.- Solicitar al usuario el nombre de un pokemon p.e.pikachu
//   3.- Solicitar toda la informacion de ese pokemon: 
//         https://pokeapi.co/api/v2/pokemon/pikachu
//   4.- Procesar la respuesta y mostrar la informacion




