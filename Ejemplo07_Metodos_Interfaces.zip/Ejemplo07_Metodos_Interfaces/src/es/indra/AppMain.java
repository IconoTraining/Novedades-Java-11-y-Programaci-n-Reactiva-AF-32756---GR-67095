package es.indra;

import es.indra.business.ItfzMetodos;

public class AppMain {

	public static void main(String[] args) {
		
		// Los recursos estaticos no necesitan instancias
		ItfzMetodos.estatico();
		
		ItfzMetodos itfz = new ItfzMetodos() {
		};
		itfz.defecto();
		
		System.out.println(itfz.procesarTexto("Buenas tardes"));

	}

}
