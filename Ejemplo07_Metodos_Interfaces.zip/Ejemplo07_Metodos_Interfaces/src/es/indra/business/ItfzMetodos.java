package es.indra.business;

public interface ItfzMetodos {
	
	// A partir de Java 8: metodos estaticos y default
	public static void estatico() {
		System.out.println("Metodo estatico");
	}
	
	public default void defecto() {
		System.out.println("Metodo default");
	}
	
	
	// A partir de Java 11: metodos privados
	private String mayusculas(String texto) {
		return texto.toUpperCase();
	}
	
	private String minusculas(String texto) {
		return texto.toLowerCase();
	}
	
	// La unica forma que tenemos de acceder a los metodo privados es desde 
	// los metodos default
	public default String procesarTexto(String texto) {
		return "Mayusculas: " + mayusculas(texto) + "\n" +
	           "Minusculas: " + minusculas(texto);
	}

}
