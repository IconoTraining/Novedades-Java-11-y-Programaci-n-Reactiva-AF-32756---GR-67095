/**
 * 
 */
/**
 * 
 */
module Ejemplo02_Uso_Modulos {
	
	// Para poder utilizar el modulo de otro proyecto
	// es necesario agregarlo como dependencia en el Build Path
	requires Ejemplo01_Modulos;
}