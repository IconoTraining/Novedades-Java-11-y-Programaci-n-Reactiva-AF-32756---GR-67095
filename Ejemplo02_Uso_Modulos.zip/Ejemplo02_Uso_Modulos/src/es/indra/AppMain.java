package es.indra;

import es.indra.models.Direccion;
import es.indra.models.Empleado;

public class AppMain {

	public static void main(String[] args) {
		
		Direccion dir1 = new Direccion("Mayor", 27, "Madrid");
		Empleado empleado = new Empleado(1, "Pepito", 43000, dir1);
		
		System.out.println(empleado);

	}

}


