package es.indra.business;

import java.util.concurrent.Flow;
import java.util.concurrent.Flow.Subscription;

public class Subscriptor implements Flow.Subscriber<Integer>{
	
	private Flow.Subscription subscription;

	@Override
	public void onSubscribe(Subscription subscription) {
		this.subscription = subscription;
		subscription.request(1);
	}

	@Override
	public void onNext(Integer item) {
		// Recibe el mensaje
		System.out.println("Mensaje recibido: " + item);
		subscription.request(1);
		
	}

	@Override
	public void onError(Throwable error) {
		error.printStackTrace();
	}

	@Override
	public void onComplete() {
		System.out.println("Subscriptor completo");
	}

}
