package es.indra;

import java.util.concurrent.Flow;

import es.indra.business.Publicador;
import es.indra.business.Subscriptor;

public class AppMain {

	public static void main(String[] args) throws InterruptedException {
		
		// Crear el publicador
		Publicador publicador = new Publicador();
		
		// Crear el procesador
		Flow.Processor<Integer, Integer> processor = new Publicador();
		
		// Crear el subscriptor
		Flow.Subscriber<Integer> subcriptor = new Subscriptor();
		
		publicador.subscribe(processor);
		processor.subscribe(subcriptor);
		
		for(int i=1; i<=10; i++) {
			publicador.submit(i);
			Thread.sleep(2000);
		}
		
		publicador.close();

	}

}
