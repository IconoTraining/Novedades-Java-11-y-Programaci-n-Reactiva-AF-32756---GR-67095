/**
 * 
 */
/**
 * 
 */
module Ejercicio3_Pokemons_HTTP {
	
	requires java.net.http;
	requires org.json;
}